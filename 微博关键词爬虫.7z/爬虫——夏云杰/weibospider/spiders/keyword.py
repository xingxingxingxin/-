import time
from collections import Counter
from lxml import etree
from scrapy import Spider
from scrapy.http import Request
import time
from items import KeywordItem
from urllib.parse import unquote
from spiders.utils import time_fix, extract_weibo_content
from pymongo import MongoClient
import re
import urllib

from urllib import parse

class KeywordSpider(Spider):
    name = "keyword_spider"
    base_url = "https://s.weibo.com"
    def start_requests(self):
        headers = {
            'Host': 's.weibo.com',
            'Cookie': 'UOR=www.techweb.com.cn,widget.weibo.com,www.techweb.com.cn; SINAGLOBAL=1806281650686.4875.1633937315312; SCF=AgJyzmQ_Ni_z-vD1WhqOFRh61eBFdUGC2uhB_x019Z1g8ZNxnSLCBC7yRG8aG6uYY7DzlU-0QGxOYAZxtECV-Tc.; ALF=1666681833; SUB=_2A25Me-FEDeRhGeFN71QZ8CjIyT2IHXVvh48MrDV8PUJbkNB-LWfdkW1NQAj3bBq42YIBQuEPqqNGuxm1xO0XiYes; SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WWPhuja8yYQwl5dIYD.wlV45NHD95QNe0Bc1h5cShzpWs4Dqcj.i--NiKLWi-zpi--4iKnEi-z4i--fi-2RiKn0i--fiKnXi-is; _s_tentry=-; Apache=5897214991934.618.1635921837137; ULV=1635921837148:4:1:1:5897214991934.618.1635921837137:1635601033849; XSRF-TOKEN=d2YC3ssz7kcQCuTBLNT2pxvB; WBPSESS=uScG10TNXa0mFfsRPJg-ljbqZ-04wf-hbTr8fBc1bfs8lDVub1Ah7yTJPpMEcHC1VLog5EGCvZ8POzPf17xWwpCcY83V0Lh0Gk36ax4978chWT9WEpr58L_x19qZew4N4_p0rWL1u2yBwKu48Vebdw=='
            ,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
                          'Chrome/86.0.4240.111 Safari/537.36 '
        }
        keywords = ['edg']
        url = 'https://s.weibo.com/weibo?q={}&Refer=index&page=1'
        urls = []
        for keyword in keywords:
            urls.append(url.format(keyword))
        for url in urls:
            yield Request(url, callback=self.parse,headers=headers)

    def parse(self, response):
        if response.url.endswith('page=1'):
            page = 50
            for page_num in range(2, page+1):
                page_url = response.url.replace('page=1', 'page={}'.format(page_num))
                yield Request(page_url, self.parse, dont_filter=True, meta=response.meta)
        if response.status == 200:
            html_result = response.text
            data = etree.HTML(html_result)
            nodes = data.xpath('//div[@class="card"]')
            for node in nodes:
                try:
                    keyword_item = KeywordItem()
                    keyword = re.search(r'q=.*?&', response.url)
                    keyword = keyword.group(0).replace('q=', '').replace('&', '')
                    keyword = urllib.parse.unquote(keyword)
                    keyword_item['keyword'] = keyword                                              #微博的搜索关键词
                    now = int(time.time())
                    timeArray = time.localtime(now)
                    otherStyleTime = time.strftime("%Y/%m/%d %H:%M:%S", timeArray)
                    keyword_item['crawl_time'] = otherStyleTime                                    #微博爬取时间
                    url = node.xpath('.//p[@class="from"]/a[1]/@href')[0]
                    print(url)
                    keyword_item['weibo_url'] = 'https:' + url[:32]                                #微博详情页链接
                    # print(keyword_item['weibo_url'])
                    pattern_data = re.compile(r'[A-Z][A-Za-z0-9]{0,9}')
                    keyword_item['weibo_id'] = pattern_data.findall(keyword_item['weibo_url'])[0]  #微博id
                    content = node.xpath('.//p[@node-type="feed_list_content"]')
                    keyword_item['content'] = extract_weibo_content(content[0].xpath('string(.)').strip())          #微博文本内容
                    created_time = node.xpath('.//p[@class="from"]/a[1]/text()')[0]
                    deal_time = created_time.replace('\n','')
                    deald_time = deal_time.replace(' ', '')
                    keyword_item['created_at'] = time_fix(deald_time)                                      #微博的发布时间
                    tool = node.xpath('.//p[@class="from"]/a[2]/text()')[0]
                    deal_tool = tool.replace('\n', '')
                    deald_tool = tool.replace(' ', '')
                    keyword_item['tool'] = deald_tool                                              #发布工具
                    repost_num = node.xpath('./div[@class="card-act"]/ul/li[1]/a/text()')[-1]
                    repost_num = repost_num.replace(' ','')
                    if repost_num == '转发':
                        repost_num = '0'
                    keyword_item['repost_num'] = repost_num                                        #转发数
                    comment_num = node.xpath('./div[@class="card-act"]/ul/li[2]/a/text()')[-1]
                    comment_num = comment_num.replace(' ','')
                    if comment_num == '评论':
                        comment_num = '0'
                    keyword_item['comment_num'] = comment_num                                     #评论数
                    liked_num = node.xpath('./div[@class="card-act"]/ul/li[3]/a//span[@class="woo-like-count"]/text()')[-1]
                    liked_num = liked_num.replace(' ','')
                    if liked_num == '赞':
                        liked_num = '0'
                    keyword_item['like_num'] = liked_num                                          #点赞数
                    keyword_item['user_url'] = node.xpath('.//div[@class="avator"]/a[1]/@href')[0]#用户主页链接
                    pat_data = re.compile(r'[0-9]{0,10}')
                    keyword_item['user_id'] = pat_data.findall(keyword_item['user_url'])[12]      #用户id

                    yield keyword_item

                except Exception as e:
                    self.logger.error(e)
