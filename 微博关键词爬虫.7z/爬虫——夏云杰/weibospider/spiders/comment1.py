#!/usr/bin/env python
# encoding: utf-8

import re
from lxml import etree
from scrapy import Spider
from scrapy.http import Request
import time
from items import Comment1Item
from spiders.utils import extract_comment_content, time_fix
from pymongo import MongoClient
import json

class Comment1Spider(Spider):
    name = "comment1_spider"
    base_url = "https://weibo.com"

    def start_requests(self):
        connect = MongoClient('localhost')
        db = connect.edg
        key = db.Keyword
        cursor1 = key.distinct('weibo_id')
        tweet_ids = list(cursor1)
        id_urls = []
        for tweet_id in tweet_ids:
            id_url = 'https://weibo.com/ajax/statuses/show?id=' + str(tweet_id)
            yield Request(id_url, callback=self.mid_parse)

    def mid_parse(self,response):
        headers = {
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
            "accept-encoding": "gzip, deflate, br",
            "accept-language": "zh-CN,zh;q=0.9,en;q=0.8",
            "cache-control": "max-age=0",
            "cookie": 'UOR=www.techweb.com.cn,widget.weibo.com,www.techweb.com.cn; SINAGLOBAL=1806281650686.4875.1633937315312; SCF=AgJyzmQ_Ni_z-vD1WhqOFRh61eBFdUGC2uhB_x019Z1g8ZNxnSLCBC7yRG8aG6uYY7DzlU-0QGxOYAZxtECV-Tc.; ALF=1666681833; SUB=_2A25Me-FEDeRhGeFN71QZ8CjIyT2IHXVvh48MrDV8PUJbkNB-LWfdkW1NQAj3bBq42YIBQuEPqqNGuxm1xO0XiYes; SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WWPhuja8yYQwl5dIYD.wlV45NHD95QNe0Bc1h5cShzpWs4Dqcj.i--NiKLWi-zpi--4iKnEi-z4i--fi-2RiKn0i--fiKnXi-is; ULV=1636422224596:13:10:8:8492491250872.754.1636422224585:1636338490235; XSRF-TOKEN=SDEaQFKiqQsK74yUQZDXoInf; WBPSESS=uScG10TNXa0mFfsRPJg-ljbqZ-04wf-hbTr8fBc1bfs8lDVub1Ah7yTJPpMEcHC1HbwM-ih6hjVfN229PfCSF00CPYUNnx7dEZz1S3Cwo6BX1B5hkyMU3X_oF0y-X3_VxhDuHrQ0PKZfe5osJ4yfZw==',
            "referer": "https://www.weibo.com/u/5644764907?topnav=1&wvr=6&topsug=1",
            "upgrade-insecure-requests": "1",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.96 Safari/537.36",
        }
        json_page = json.loads(response.text)
        mid = json_page["id"]
        print(mid)
        comment_url = 'https://weibo.com/aj/v6/comment/big?ajwvr=6&id={}&from=singleWeiBo&page=1'.format(mid)
        yield Request(comment_url, callback=self.parse, headers=headers,meta=response.meta)

    def parse(self, response):
        if response.url.endswith('page=1'):
            page = 50
            for page_num in range(2, page+1):
                page_url = response.url.replace('page=1', 'page={}'.format(page_num))
                yield Request(page_url, self.parse, dont_filter=True, meta=response.meta)

        res = json.loads(response.text)
        count = res['data']['count']
        html = etree.HTML(res['data']['html'])
        name = html.xpath("//div[@class='list_li S_line1 clearfix']/div[@class='WB_face W_fl']/a/img/@alt")  # 评论人的姓名
        info = html.xpath("//div[@node-type='replywrap']/div[@class='WB_text']/text()")  # 评论信息
        info = "".join(info).replace(" ", "").split("\n")
        info.pop(0)
        comment_time = html.xpath("//div[@class='WB_from S_txt2']/text()")  # 评论时间
        name_url = html.xpath("//div[@class='WB_face W_fl']/a/@href")  # 评论人的url
        name_url = ["https:" + i for i in name_url]
        for i in range(len(name)):
            try:
                CommentItem1 = Comment1Item()
                CommentItem1["name"] = name[i] # 存储评论人的网名
                CommentItem1["comment_info"] = info[i] # 存储评论的信息
                CommentItem1["comment_time"] = comment_time[i] # 存储评论时间
                CommentItem1["comment_url"] = name_url[i] # 存储评论人的相关主页
                yield CommentItem1
            except Exception as e:
                self.logger.error(e)
